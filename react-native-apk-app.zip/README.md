# React Native APK App

## Sida loo isticmaalo
```bash
npm install
npm run start
```

## GitHub Actions
Push samee si APK si automatic ah loo dhiso.
